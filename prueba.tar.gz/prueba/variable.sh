#!/bin/sh
export LOGNAME=dleon
export SYNOPSYS_HOME=/mnt/vol_NFS_Zener/tools/synopsys/apps/
export VCS_HOME=/mnt/vol_NFS_Zener/tools/synopsys/apps/vcs-mx2/M-2017.03
export PATH=$PATH:$VCS_HOME/linux64/bin
export SNPSLMD_LICENSE_FILE=27000@172.21.9.211
export UVM_HOME=/mnt/vol_NFS_Zener/WD_ESPEC/gcastro/memory/sdr_ctrl/trunk/verif/UVM_lib/1800.2-2017-1.1/


